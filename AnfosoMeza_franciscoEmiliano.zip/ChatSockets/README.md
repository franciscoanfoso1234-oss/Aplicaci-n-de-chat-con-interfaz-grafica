# ChatSockets - Java + Swing

Aplicación de chat basada en sockets con servidor y cliente gráfico.

## Características

- Autenticación de usuarios mediante archivo `users.txt`.
- Rechazo de credenciales incorrectas.
- Rechazo de sesiones duplicadas.
- Mensajes privados entre clientes conectados.
- Notificación de conexiones y desconexiones de usuarios visibles.
- Comando `/lista` para obtener usuarios conectados.
- Modo invisible con `/invisible`.
- Interfaz gráfica en Swing.
- Historia desplazable de mensajes.
- Lista de usuarios conectados con selección por clic.
- Diferenciación visual entre mensajes propios, recibidos, sistema y errores.
- Indicador de estado de conexión.
- Interfaz no bloqueante: lectura y escritura de red en hilos separados.

## Requisitos

- JDK 8 o superior. Probado con JDK 17.
- No se necesitan librerías externas.

## Estructura del proyecto

```text
ChatSockets/
├── README.md
├── MANUAL_USUARIO.md
├── users.txt
├── src/
│   └── chat/
│       ├── Server.java
│       ├── Client.java
│       ├── LoginFrame.java
│       ├── ChatFrame.java
│       └── ChatConnection.java
└── docs/
    └── capturas/