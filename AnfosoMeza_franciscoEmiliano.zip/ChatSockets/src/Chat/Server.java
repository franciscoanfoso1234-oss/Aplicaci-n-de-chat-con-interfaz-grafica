package Chat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

public class Server {

    private static final Map<String, String> registeredUsers = new ConcurrentHashMap<>();
    private static final Map<String, ClientHandler> clients = new ConcurrentHashMap<>();

    public static void main(String[] args) {
        int port = 9090;

        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("Puerto inválido. Se usará 9090.");
            }
        }

        loadUsers("users.txt");
        System.out.println("Usuarios registrados cargados: " + registeredUsers.size());

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Servidor de chat escuchando en puerto " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(clientSocket);
                handler.start();
            }
        } catch (IOException e) {
            System.err.println("Error fatal del servidor: " + e.getMessage());
        }
    }

    private static void loadUsers(String path) {
        File file = new File(path);

        if (!file.exists()) {
            System.out.println("No se encontró " + path + ". Creando archivo de ejemplo...");
            try (PrintWriter pw = new PrintWriter(
                    new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8), true)) {

                pw.println("# Formato: usuario:contraseña");
                pw.println("# Para la práctica se usa texto plano. En producción usar hash.");
                pw.println("null:null123");
                pw.println("pedro:pedro123");
                pw.println("ana:ana123");
                pw.println("lucia:lucia123");

            } catch (IOException e) {
                System.err.println("No se pudo crear users.txt: " + e.getMessage());
                return;
            }
        }

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {

            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();

                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }

                String[] parts = line.split(":", 2);
                if (parts.length == 2) {
                    registeredUsers.put(parts[0].trim(), parts[1]);
                } else {
                    System.err.println("Línea inválida en users.txt: " + line);
                }
            }

        } catch (IOException e) {
            System.err.println("Error leyendo users.txt: " + e.getMessage());
        }
    }

    private static boolean checkCredentials(String username, String password) {
        String stored = registeredUsers.get(username);
        return stored != null && stored.equals(password);
    }

    private static void refreshUserLists() {
        for (ClientHandler handler : clients.values()) {
            handler.sendUserList();
        }
    }

    private static void broadcastSystem(String message, String excludedUsername) {
        for (ClientHandler handler : clients.values()) {
            if (!Objects.equals(handler.getUsername(), excludedUsername)) {
                handler.sendSystem(message);
            }
        }
    }

    private static class ClientHandler extends Thread {

        private final Socket socket;
        private BufferedReader in;
        private PrintWriter out;

        private volatile String username;
        private volatile boolean invisible;

        ClientHandler(Socket socket) {
            this.socket = socket;
            setDaemon(true);
            setName("handler-" + socket.getRemoteSocketAddress());
        }

        String getUsername() {
            return username;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                out = new PrintWriter(
                        new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

                String line = in.readLine();
                if (line == null) {
                    return;
                }

                String[] login = line.split("\\|", 3);
                if (login.length < 3 || !"LOGIN".equals(login[0])) {
                    sendError("Protocolo de acceso inválido.");
                    return;
                }

                String user = login[1].trim();
                String pass = login[2];

                if (user.isEmpty()) {
                    sendError("El usuario no puede estar vacío.");
                    return;
                }

                if (!checkCredentials(user, pass)) {
                    sendError("Usuario o contraseña incorrectos.");
                    return;
                }

                ClientHandler previous = clients.putIfAbsent(user, this);
                if (previous != null) {
                    sendError("Ya existe una sesión iniciada para el usuario '" + user + "'.");
                    return;
                }

                username = user;
                sendLine("AUTH_OK|" + username);
                System.out.println("[" + username + "] autenticado desde " + socket.getRemoteSocketAddress());

                refreshUserLists();
                broadcastSystem("✔ " + username + " se ha conectado.", username);

                while ((line = in.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) {
                        continue;
                    }

                    if ("QUIT".equals(line)) {
                        break;
                    } else if (line.startsWith("CMD|")) {
                        handleCommand(line.substring(4));
                    } else if (line.startsWith("MSG|")) {
                        handlePrivateMessage(line.substring(4));
                    } else {
                        sendError("Mensaje no reconocido.");
                    }
                }

            } catch (IOException e) {
                if (username != null) {
                    System.out.println("[" + username + "] error de E/S: " + e.getMessage());
                }
            } finally {
                cleanup();
            }
        }

        private void handleCommand(String command) {
            String cmd = command.trim();

            if (cmd.equalsIgnoreCase("/lista")) {
                sendUserList();
            } else if (cmd.equalsIgnoreCase("/invisible")) {
                invisible = !invisible;
                sendLine("STATUS|" + invisible);
                refreshUserLists();
                System.out.println("[" + username + "] invisible=" + invisible);
            } else {
                sendError("Comando desconocido: " + cmd);
            }
        }

        private void handlePrivateMessage(String payload) {
            String[] parts = payload.split("\\|", 2);
            if (parts.length < 2) {
                sendError("Formato de mensaje privado inválido.");
                return;
            }

            String to = parts[0].trim();
            String text = parts[1];

            if (to.isEmpty()) {
                sendError("Destinatario vacío.");
                return;
            }

            if (text.trim().isEmpty()) {
                sendError("El mensaje no puede estar vacío.");
                return;
            }

            if (to.equals(username)) {
                sendError("No puedes enviarte mensajes a ti mismo.");
                return;
            }

            ClientHandler target = clients.get(to);
            if (target == null) {
                sendError("El usuario '" + to + "' no está conectado.");
                return;
            }

            target.sendPrivateMessage(username, text);
        }

        private void sendPrivateMessage(String from, String text) {
            sendLine("MSG|" + from + "|" + username + "|" + text);
        }

        private void sendSystem(String message) {
            sendLine("SYS|" + message);
        }

        private void sendError(String message) {
            sendLine("ERROR|" + message);
        }

        private void sendUserList() {
            if (username == null) {
                return;
            }

            List<String> names = new ArrayList<>();

            for (ClientHandler handler : clients.values()) {
                String u = handler.username;
                if (u == null) {
                    continue;
                }

                // Los invisibles no aparecen para los demás, pero sí se ven a sí mismos.
                if (!handler.invisible || handler == this) {
                    names.add(u);
                }
            }

            Collections.sort(names);

            StringBuilder sb = new StringBuilder("USER_LIST|");
            for (int i = 0; i < names.size(); i++) {
                if (i > 0) {
                    sb.append(',');
                }
                sb.append(names.get(i));
            }

            sendLine(sb.toString());
        }

        private void sendLine(String line) {
            if (out == null || socket.isClosed()) {
                return;
            }

            synchronized (out) {
                out.println(line);
                out.flush();
            }
        }

        private void cleanup() {
            String user = username;

            if (user != null) {
                boolean wasVisible = !invisible;

                clients.remove(user, this);
                refreshUserLists();

                // Si estaba invisible, no se anuncia su desconexión para mantener el ocultamiento.
                if (wasVisible) {
                    broadcastSystem("⚠ " + user + " se ha desconectado.", user);
                }

                System.out.println("[" + user + "] desconectado.");
            }

            closeQuietly();
        }

        private void closeQuietly() {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ignored) {
            }

            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception ignored) {
            }

            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException ignored) {
            }
        }
    }
}