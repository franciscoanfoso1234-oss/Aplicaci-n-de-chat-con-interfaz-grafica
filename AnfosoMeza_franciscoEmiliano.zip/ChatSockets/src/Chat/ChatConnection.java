package Chat;

import javax.swing.SwingUtilities;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ChatConnection {

    public interface Listener {
        void onConnected(String username);
        void onUserList(List<String> users);
        void onPrivateMessage(String from, String to, String text);
        void onSystemMessage(String text);
        void onErrorMessage(String text);
        void onInvisibleChanged(boolean invisible);
        void onDisconnected(String reason);
    }

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    private volatile String username;
    private volatile boolean invisible;
    private volatile boolean closed;
    private volatile boolean disconnectNotified;

    private Listener listener;
    private Thread readerThread;

    private final ExecutorService sendExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "chat-sender");
        t.setDaemon(true);
        return t;
    });

    public void connect(String host, int port) throws IOException {
        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), 5000);
        socket.setTcpNoDelay(true);

        in = new BufferedReader(
                new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        out = new PrintWriter(
                new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
    }

    public String login(String user, String pass) throws IOException {
        sendSync("LOGIN|" + user + "|" + pass);

        String line = in.readLine();
        if (line == null) {
            return "El servidor cerró la conexión durante el acceso.";
        }

        if (line.startsWith("AUTH_OK|")) {
            username = line.substring("AUTH_OK|".length());
            return null;
        }

        if (line.startsWith("ERROR|")) {
            return line.substring("ERROR|".length());
        }

        return "Respuesta inesperada del servidor.";
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void startListening() {
        if (readerThread != null || closed) {
            return;
        }

        final Listener l = listener;
        if (l != null) {
            SwingUtilities.invokeLater(() -> l.onConnected(username));
        }

        readerThread = new Thread(this::readLoop, "chat-reader");
        readerThread.setDaemon(true);
        readerThread.start();
    }

    public String getUsername() {
        return username;
    }

    public boolean isInvisible() {
        return invisible;
    }

    public void sendPrivate(String to, String text) {
        sendAsync("MSG|" + to + "|" + text);
    }

    public void sendListRequest() {
        sendAsync("CMD|/lista");
    }

    public void sendInvisibleToggle() {
        sendAsync("CMD|/invisible");
    }

    public void sendQuit() {
        sendAsync("QUIT");
    }

    public void close() {
        if (closed) {
            return;
        }

        closed = true;
        sendExecutor.shutdown();
        closeSocketResources();
        fireDisconnected("Conexión cerrada.");
    }

    private void readLoop() {
        try {
            String line;
            while (!closed && (line = in.readLine()) != null) {
                processLine(line);
            }
        } catch (IOException e) {
            if (!closed) {
                fireDisconnected("Conexión perdida: " + e.getMessage());
            }
        } finally {
            if (!closed) {
                if (!disconnectNotified) {
                    fireDisconnected("El servidor ha cerrado la conexión.");
                }
                close();
            }
        }
    }

    private void processLine(String line) {
        if (line.startsWith("USER_LIST|")) {
            String data = line.substring("USER_LIST|".length());
            List<String> users = new ArrayList<>();

            if (!data.isEmpty()) {
                for (String token : data.split(",")) {
                    String user = token.trim();
                    if (!user.isEmpty()) {
                        users.add(user);
                    }
                }
            }

            fireUserList(users);

        } else if (line.startsWith("MSG|")) {
            String[] parts = line.split("\\|", 4);
            if (parts.length >= 4) {
                firePrivate(parts[1], parts[2], parts[3]);
            }

        } else if (line.startsWith("SYS|")) {
            fireSystem(line.substring("SYS|".length()));

        } else if (line.startsWith("ERROR|")) {
            fireError(line.substring("ERROR|".length()));

        } else if (line.startsWith("STATUS|")) {
            invisible = Boolean.parseBoolean(line.substring("STATUS|".length()));
            fireInvisible(invisible);
        }
    }

    private void sendAsync(String line) {
        if (closed) {
            return;
        }

        sendExecutor.submit(() -> {
            try {
                sendSync(line);
            } catch (IOException e) {
                fireDisconnected("Error al enviar mensaje: " + e.getMessage());
                close();
            }
        });
    }

    private void sendSync(String line) throws IOException {
        if (closed || socket == null || socket.isClosed() || out == null) {
            throw new IOException("La conexión está cerrada.");
        }

        synchronized (out) {
            out.println(line);
            out.flush();

            if (out.checkError()) {
                throw new IOException("No se pudo escribir en el socket.");
            }
        }
    }

    private void closeSocketResources() {
        try {
            if (in != null) {
                in.close();
            }
        } catch (IOException ignored) {
        }

        try {
            if (out != null) {
                out.close();
            }
        } catch (Exception ignored) {
        }

        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException ignored) {
        }
    }

    private void fireUserList(List<String> users) {
        dispatch(l -> l.onUserList(users));
    }

    private void firePrivate(String from, String to, String text) {
        dispatch(l -> l.onPrivateMessage(from, to, text));
    }

    private void fireSystem(String text) {
        dispatch(l -> l.onSystemMessage(text));
    }

    private void fireError(String text) {
        dispatch(l -> l.onErrorMessage(text));
    }

    private void fireInvisible(boolean inv) {
        dispatch(l -> l.onInvisibleChanged(inv));
    }

    private void fireDisconnected(String reason) {
        if (disconnectNotified) {
            return;
        }

        disconnectNotified = true;
        dispatch(l -> l.onDisconnected(reason));
    }

    private void dispatch(ListenerAction action) {
        final Listener l = listener;
        if (l == null) {
            return;
        }

        SwingUtilities.invokeLater(() -> action.run(l));
    }

    private interface ListenerAction {
        void run(Listener listener);
    }
}