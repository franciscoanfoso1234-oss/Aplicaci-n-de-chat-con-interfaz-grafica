package Chat;

import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JToggleButton;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ChatFrame extends JFrame implements ChatConnection.Listener {

    private static final Color BG_APP = new Color(248, 249, 250);
    private static final Color BG_OWN = new Color(223, 240, 255);
    private static final Color BG_RECEIVED = new Color(240, 240, 240);

    private static final Color FG_OWN = new Color(0, 80, 150);
    private static final Color FG_RECEIVED = new Color(30, 30, 30);
    private static final Color FG_SYSTEM = new Color(100, 100, 100);
    private static final Color FG_ERROR = new Color(180, 30, 30);

    private final ChatConnection connection;
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");

    private JTextPane chatPane;
    private DefaultListModel<String> userModel;
    private JList<String> userList;

    private JTextField inputField;
    private JButton sendButton;

    private JLabel statusLabel;
    private JLabel destinationLabel;
    private JToggleButton invisibleButton;

    private Style ownStyle;
    private Style receivedStyle;
    private Style systemStyle;
    private Style errorStyle;

    private volatile boolean updatingInvisible = false;
    private String currentRecipient = null;

    public ChatFrame(ChatConnection connection) {
        this.connection = connection;

        setTitle("Chat - " + connection.getUsername());
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setSize(1000, 650);
        setMinimumSize(new Dimension(780, 520));
        setLocationRelativeTo(null);

        initComponents();

        appendSystem("Conectado como " + connection.getUsername()
                + ". Selecciona un usuario o usa: /msg usuario mensaje");
    }

    private void initComponents() {
        getContentPane().setBackground(BG_APP);
        setLayout(new BorderLayout(10, 10));

        JPanel topPanel = new JPanel(new BorderLayout(10, 0));
        topPanel.setBackground(BG_APP);
        topPanel.setBorder(new EmptyBorder(10, 12, 0, 12));

        statusLabel = new JLabel("Conectado");
        statusLabel.setFont(statusLabel.getFont().deriveFont(Font.BOLD, 13f));

        invisibleButton = new JToggleButton("Modo invisible");
        invisibleButton.setFocusPainted(false);
        invisibleButton.addActionListener(e -> {
            if (!updatingInvisible) {
                connection.sendInvisibleToggle();
            }
        });

        topPanel.add(statusLabel, BorderLayout.WEST);
        topPanel.add(invisibleButton, BorderLayout.EAST);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(230);
        splitPane.setContinuousLayout(true);
        splitPane.setBorder(null);
        splitPane.setBackground(BG_APP);

        JPanel usersPanel = new JPanel(new BorderLayout(0, 8));
        usersPanel.setBackground(BG_APP);
        usersPanel.setBorder(new EmptyBorder(10, 12, 10, 6));

        JLabel usersTitle = new JLabel("Usuarios conectados");
        usersTitle.setFont(usersTitle.getFont().deriveFont(Font.BOLD, 13f));

        userModel = new DefaultListModel<>();
        userList = new JList<>(userModel);
        userList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userList.setFont(new Font("SansSerif", Font.PLAIN, 13));
        userList.setFixedCellHeight(24);
        userList.setBackground(Color.WHITE);
        userList.setBorder(new LineBorder(new Color(210, 210, 210)));

        userList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

                String name = String.valueOf(value);
                if (name.equals(connection.getUsername())) {
                    setText(name + " (tú)");
                } else {
                    setText(name);
                }

                setBorder(new EmptyBorder(2, 6, 2, 6));
                return this;
            }
        });

        userList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selected = userList.getSelectedValue();
                currentRecipient = selected;

                if (selected == null) {
                    destinationLabel.setText("Destinatario: ninguno");
                } else {
                    destinationLabel.setText("Destinatario: " + selected);
                    inputField.requestFocusInWindow();
                }
            }
        });

        JScrollPane usersScroll = new JScrollPane(userList);
        usersScroll.setBorder(null);

        usersPanel.add(usersTitle, BorderLayout.NORTH);
        usersPanel.add(usersScroll, BorderLayout.CENTER);

        JPanel chatPanel = new JPanel(new BorderLayout(8, 8));
        chatPanel.setBackground(BG_APP);
        chatPanel.setBorder(new EmptyBorder(10, 6, 10, 12));

        chatPane = new JTextPane();
        chatPane.setEditable(false);
        chatPane.setFont(new Font("SansSerif", Font.PLAIN, 13));
        chatPane.setBackground(Color.WHITE);
        chatPane.setBorder(new LineBorder(new Color(210, 210, 210)));

        initStyles();

        JScrollPane chatScroll = new JScrollPane(chatPane);
        chatScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        chatScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        chatScroll.setBorder(null);

        JPanel inputPanel = new JPanel(new BorderLayout(8, 8));
        inputPanel.setBackground(BG_APP);

        destinationLabel = new JLabel("Destinatario: ninguno");
        destinationLabel.setFont(destinationLabel.getFont().deriveFont(Font.PLAIN, 12f));

        inputField = new JTextField();
        inputField.setFont(new Font("SansSerif", Font.PLAIN, 13));
        inputField.setBorder(new LineBorder(new Color(200, 200, 200), 1, true));

        sendButton = new JButton("Enviar");
        sendButton.setFocusPainted(false);
        sendButton.setPreferredSize(new Dimension(90, 32));

        inputField.addActionListener(e -> sendMessage());
        sendButton.addActionListener(e -> sendMessage());

        JPanel inputRow = new JPanel(new BorderLayout(8, 0));
        inputRow.setBackground(BG_APP);
        inputRow.add(inputField, BorderLayout.CENTER);
        inputRow.add(sendButton, BorderLayout.EAST);

        inputPanel.add(destinationLabel, BorderLayout.NORTH);
        inputPanel.add(inputRow, BorderLayout.CENTER);

        chatPanel.add(chatScroll, BorderLayout.CENTER);
        chatPanel.add(inputPanel, BorderLayout.SOUTH);

        splitPane.setLeftComponent(usersPanel);
        splitPane.setRightComponent(chatPanel);

        add(topPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                connection.sendQuit();
                connection.close();
                System.exit(0);
            }
        });
    }

    private void initStyles() {
        StyledDocument doc = chatPane.getStyledDocument();

        ownStyle = doc.addStyle("own", null);
        StyleConstants.setForeground(ownStyle, FG_OWN);
        StyleConstants.setBackground(ownStyle, BG_OWN);
        StyleConstants.setAlignment(ownStyle, StyleConstants.ALIGN_RIGHT);
        StyleConstants.setRightIndent(ownStyle, 0);
        StyleConstants.setLeftIndent(ownStyle, 60);
        StyleConstants.setSpaceAbove(ownStyle, 6);
        StyleConstants.setSpaceBelow(ownStyle, 6);

        receivedStyle = doc.addStyle("received", null);
        StyleConstants.setForeground(receivedStyle, FG_RECEIVED);
        StyleConstants.setBackground(receivedStyle, BG_RECEIVED);
        StyleConstants.setAlignment(receivedStyle, StyleConstants.ALIGN_LEFT);
        StyleConstants.setLeftIndent(receivedStyle, 0);
        StyleConstants.setRightIndent(receivedStyle, 60);
        StyleConstants.setSpaceAbove(receivedStyle, 6);
        StyleConstants.setSpaceBelow(receivedStyle, 6);

        systemStyle = doc.addStyle("system", null);
        StyleConstants.setForeground(systemStyle, FG_SYSTEM);
        StyleConstants.setAlignment(systemStyle, StyleConstants.ALIGN_CENTER);
        StyleConstants.setItalic(systemStyle, true);
        StyleConstants.setSpaceAbove(systemStyle, 4);
        StyleConstants.setSpaceBelow(systemStyle, 4);

        errorStyle = doc.addStyle("error", null);
        StyleConstants.setForeground(errorStyle, FG_ERROR);
        StyleConstants.setAlignment(errorStyle, StyleConstants.ALIGN_CENTER);
        StyleConstants.setBold(errorStyle, true);
        StyleConstants.setSpaceAbove(errorStyle, 4);
        StyleConstants.setSpaceBelow(errorStyle, 4);
    }

    private void sendMessage() {
        String text = inputField.getText().trim();
        if (text.isEmpty()) {
            return;
        }

        inputField.setText("");

        if (text.startsWith("/")) {
            handleSlashCommand(text);
            return;
        }

        if (currentRecipient == null) {
            appendError("Selecciona un destinatario en la lista o usa: /msg usuario mensaje");
            return;
        }

        if (currentRecipient.equals(connection.getUsername())) {
            appendError("No puedes enviarte mensajes a ti mismo.");
            return;
        }

        connection.sendPrivate(currentRecipient, text);
        appendOwn(text);
    }

    private void handleSlashCommand(String text) {
        String lower = text.toLowerCase();

        if (text.equalsIgnoreCase("/lista")) {
            connection.sendListRequest();
            appendSystem("Has solicitado la lista de usuarios conectados.");

        } else if (text.equalsIgnoreCase("/invisible")) {
            connection.sendInvisibleToggle();

        } else if (lower.startsWith("/msg ")) {
            String rest = text.substring(5).trim();
            int space = rest.indexOf(' ');

            if (space < 0) {
                appendError("Uso correcto: /msg usuario mensaje");
                return;
            }

            String to = rest.substring(0, space).trim();
            String message = rest.substring(space + 1).trim();

            if (to.isEmpty() || message.isEmpty()) {
                appendError("Uso correcto: /msg usuario mensaje");
                return;
            }

            if (to.equals(connection.getUsername())) {
                appendError("No puedes enviarte mensajes a ti mismo.");
                return;
            }

            connection.sendPrivate(to, message);

            currentRecipient = to;
            destinationLabel.setText("Destinatario: " + to);

            appendOwn(message);

        } else {
            appendError("Comando desconocido. Comandos disponibles: /lista, /invisible, /msg usuario mensaje");
        }
    }

    private void appendOwn(String text) {
        appendStyled("Tú", text, ownStyle);
    }

    private void appendReceived(String from, String text) {
        appendStyled(from, text, receivedStyle);
    }

    private void appendSystem(String text) {
        appendStyled("Sistema", text, systemStyle);
    }

    private void appendError(String text) {
        appendStyled("Error", text, errorStyle);
    }

    private void appendStyled(String sender, String text, Style style) {
        StyledDocument doc = chatPane.getStyledDocument();
        String time = timeFormat.format(new Date());
        String content = sender + " · " + time + "\n" + text + "\n\n";

        try {
            doc.insertString(doc.getLength(), content, style);
        } catch (BadLocationException ignored) {
        }

        chatPane.setCaretPosition(doc.getLength());
    }

    @Override
    public void onConnected(String username) {
        statusLabel.setText("Conectado como " + username);
    }

    @Override
    public void onUserList(List<String> users) {
        String previous = userList.getSelectedValue();

        userModel.clear();
        for (String user : users) {
            userModel.addElement(user);
        }

        if (previous != null && users.contains(previous)) {
            userList.setSelectedValue(previous, true);
            currentRecipient = previous;
            destinationLabel.setText("Destinatario: " + previous);
        } else {
            currentRecipient = null;
            destinationLabel.setText("Destinatario: ninguno");
        }
    }

    @Override
    public void onPrivateMessage(String from, String to, String text) {
        if (!to.equals(connection.getUsername())) {
            return;
        }

        appendReceived(from, text);
    }

    @Override
    public void onSystemMessage(String text) {
        appendSystem(text);
    }

    @Override
    public void onErrorMessage(String text) {
        appendError(text);
    }

    @Override
    public void onInvisibleChanged(boolean invisible) {
        updatingInvisible = true;
        invisibleButton.setSelected(invisible);
        invisibleButton.setText(invisible ? "Invisible: activado" : "Modo invisible");
        updatingInvisible = false;

        appendSystem(invisible
                ? "Has activado el modo invisible. No apareces en la lista de los demás."
                : "Has desactivado el modo invisible. Ahora eres visible.");
    }

    @Override
    public void onDisconnected(String reason) {
        statusLabel.setText("Desconectado");
        appendError(reason);

        inputField.setEnabled(false);
        sendButton.setEnabled(false);
        invisibleButton.setEnabled(false);
        userList.setEnabled(false);
    }
}