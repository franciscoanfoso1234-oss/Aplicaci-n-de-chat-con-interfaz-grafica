package Chat;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Client {

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // Se usa el look and feel por defecto si Nimbus no está disponible.
        }

        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            try {
                loginFrame.getClass().getMethod("setVisible", boolean.class).invoke(loginFrame, true);
            } catch (NoSuchMethodException ignored) {
                try {
                    loginFrame.getClass().getMethod("show").invoke(loginFrame);
                } catch (ReflectiveOperationException ignored2) {
                    // LoginFrame handles its own display in the constructor.
                }
            } catch (ReflectiveOperationException e) {
                throw new RuntimeException(e);
            }
        });
    }
}