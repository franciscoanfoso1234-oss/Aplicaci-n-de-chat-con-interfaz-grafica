package Chat;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

public class LoginFrame extends JFrame {

    private final JTextField hostField = new JTextField("localhost", 15);
    private final JTextField portField = new JTextField("9090", 6);
    private final JTextField userField = new JTextField(15);
    private final JPasswordField passField = new JPasswordField(15);

    private final JLabel statusLabel = new JLabel(" ");
    private final JButton connectButton = new JButton("Conectar");

    public LoginFrame() {
        setTitle("Chat - Inicio de sesión");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(430, 290);
        setResizable(false);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel content = new JPanel(new GridBagLayout());
        content.setBackground(new Color(248, 249, 250));
        content.setBorder(new EmptyBorder(20, 24, 20, 24));

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6, 6, 6, 6);
        gc.anchor = GridBagConstraints.WEST;

        addRow(content, gc, 0, "Servidor:", hostField);
        addRow(content, gc, 1, "Puerto:", portField);
        addRow(content, gc, 2, "Usuario:", userField);
        addRow(content, gc, 3, "Contraseña:", passField);

        statusLabel.setForeground(new Color(180, 30, 30));
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);

        gc.gridx = 0;
        gc.gridy = 4;
        gc.gridwidth = 2;
        gc.fill = GridBagConstraints.HORIZONTAL;
        content.add(statusLabel, gc);

        gc.gridwidth = 1;
        gc.fill = GridBagConstraints.NONE;
        gc.anchor = GridBagConstraints.EAST;
        gc.gridx = 1;
        gc.gridy = 5;
        content.add(connectButton, gc);

        connectButton.addActionListener(e -> tryConnect());
        passField.addActionListener(e -> tryConnect());
        getRootPane().setDefaultButton(connectButton);

        setContentPane(content);
    }

    private void addRow(JPanel panel, GridBagConstraints gc, int row, String label, JComponent field) {
        gc.gridx = 0;
        gc.gridy = row;
        gc.weightx = 0;
        panel.add(new JLabel(label), gc);

        gc.gridx = 1;
        gc.weightx = 1;
        gc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(field, gc);

        gc.fill = GridBagConstraints.NONE;
    }

    private void tryConnect() {
        String host = hostField.getText().trim();
        String portText = portField.getText().trim();
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());

        if (host.isEmpty() || user.isEmpty() || pass.isEmpty()) {
            statusLabel.setText("Completa servidor, usuario y contraseña.");
            return;
        }

        int port;
        try {
            port = Integer.parseInt(portText);
        } catch (NumberFormatException ex) {
            statusLabel.setText("Puerto inválido.");
            return;
        }

        setConnecting(true);
        statusLabel.setForeground(new Color(0, 100, 0));
        statusLabel.setText("Conectando...");

        SwingWorker<ChatConnection, Void> worker = new SwingWorker<ChatConnection, Void>() {
            @Override
            protected ChatConnection doInBackground() throws Exception {
                ChatConnection connection = new ChatConnection();
                connection.connect(host, port);

                String error = connection.login(user, pass);
                if (error != null) {
                    connection.close();
                    throw new IOException(error);
                }

                return connection;
            }

            @Override
            protected void done() {
                try {
                    ChatConnection connection = get();

                    dispose();

                    ChatFrame frame = new ChatFrame(connection);
                    connection.setListener(frame);
                    connection.startListening();

                    frame.setVisible(true);

                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    statusLabel.setForeground(new Color(180, 30, 30));
                    statusLabel.setText("Operación cancelada.");
                    setConnecting(false);

                } catch (ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    statusLabel.setForeground(new Color(180, 30, 30));
                    statusLabel.setText(cause != null ? cause.getMessage() : "Error inesperado.");
                    setConnecting(false);
                }
            }
        };

        worker.execute();
    }

    private void setConnecting(boolean connecting) {
        connectButton.setEnabled(!connecting);
        hostField.setEnabled(!connecting);
        portField.setEnabled(!connecting);
        userField.setEnabled(!connecting);
        passField.setEnabled(!connecting);
    }
}